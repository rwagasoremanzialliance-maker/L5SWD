export interface Product {
  id: string;
  name: string;
  category: string;
  section: 'supermarket' | 'clothing';
  price?: number;
  image?: string;
}

export interface Category {
  id: string;
  name: string;
  section: 'supermarket' | 'clothing';
  items: string[];
}

export const SUPERMARKET_CATEGORIES: Category[] = [
  {
    id: 'food-items',
    name: 'Food Items',
    section: 'supermarket',
    items: [
      'Tilda Pure Basmati Rice', 'India Gate Premium Rice', 'Barilla Spaghetti No.5', 'De Cecco Penne Rigate', 'Kellogg\'s Corn Flakes', 'Nestle Fitness Cereal', 'Quaker Whole Grain Oats', 'Nutella Hazelnut Spread', 'Skippy Peanut Butter', 'Ferrero Rocher Chocolates', 'Lindt Excellence 85% Dark', 'Cadbury Dairy Milk', 'Heinz Tomato Ketchup', 'Hellmann\'s Real Mayonnaise', 'Maille Dijon Mustard', 'Bertolli Extra Virgin Olive Oil', 'Filippo Berio Sunflower Oil', 'Knorr Chicken Bouillon', 'Maggi Seasoning Cubes', 'McCormick Black Pepper'
    ]
  },
  {
    id: 'fresh-products',
    name: 'Fresh Products',
    section: 'supermarket',
    items: [
      'Organic Hass Avocados', 'Premium Cavendish Bananas', 'Honeycrisp Red Apples', 'Zespri Golden Kiwi', 'Driscoll\'s Strawberries', 'Fresh Atlantic Salmon', 'Premium Wagyu Beef Steak', 'Organic Free-Range Chicken', 'Dutch Gouda Cheese', 'French Brie President', 'Kerrygold Pure Irish Butter', 'Almarai Fresh Milk', 'Chobani Greek Yogurt', 'Fresh Organic Spinach', 'Premium Vine Tomatoes'
    ]
  },
  {
    id: 'beverages',
    name: 'Beverages',
    section: 'supermarket',
    items: [
      'Evian Natural Mineral Water', 'Perrier Sparkling Water', 'San Pellegrino Aranciata', 'Coca-Cola Zero Sugar', 'Pepsi Max', 'Red Bull Energy Drink', 'Starbucks Pike Place Roast', 'Nespresso Vertuo Capsules', 'Lipton Yellow Label Tea', 'Twinings Earl Grey', 'Tropicana 100% Orange Juice', 'Ocean Spray Cranberry Juice', 'Monster Energy Ultra', 'Schweppes Tonic Water'
    ]
  },
  {
    id: 'household',
    name: 'Household Products',
    section: 'supermarket',
    items: ['Ariel All-in-1 Pods', 'Downy Fabric Softener', 'Dettol Surface Cleanser', 'Finish Dishwasher Tablets', 'Pampers Baby Wipes', 'Kleenex Ultra Soft Tissue']
  },
  {
    id: 'personal-care',
    name: 'Personal Care',
    section: 'supermarket',
    items: ['Colgate Total Toothpaste', 'Head & Shoulders Shampoo', 'Dove Deep Moisture Body Wash', 'Nivea Soft Moisturizing Cream', 'Gillette Fusion5 Razor', 'L\'Oreal Revitalift Serum']
  }
];

export const CLOTHING_CATEGORIES: Category[] = [
  {
    id: 'mens-clothing',
    name: "Men's Clothing",
    section: 'clothing',
    items: [
      'Ralph Lauren Polo Shirt', 'Hugo Boss Slim Fit Suit', 'Levi\'s 501 Original Jeans', 'Nike Tech Fleece Hoodie', 'Adidas Originals Tracksuit', 'Zara Premium Linen Shirt', 'H&M Oversized Cotton Tee', 'Calvin Klein Modern Briefs', 'Tommy Hilfiger Chinos', 'Lacoste Classic Pique Polo', 'Burberry Heritage Trench Coat', 'The North Face Nuptse Jacket', 'Patagonia Better Sweater', 'Uniqlo Airism Undershirt'
    ]
  },
  {
    id: 'womens-clothing',
    name: "Women's Clothing",
    section: 'clothing',
    items: [
      'Chanel Little Black Dress', 'Gucci Floral Silk Scarf', 'Zara High-Waist Trousers', 'H&M Conscious Silk Blouse', 'Nike Pro Training Leggings', 'Adidas Stella McCartney Set', 'Lululemon Align Yoga Pants', 'Burberry Check Cashmere Scarf', 'Prada Nylon Gabardine Skirt', 'Dior Bar Jacket', 'Max Mara Cashmere Coat', 'Victoria\'s Secret Satin Robe', 'Mango Evening Gown', 'Massimo Dutti Leather Blazer'
    ]
  },
  {
    id: 'shoes',
    name: 'Shoes',
    section: 'clothing',
    items: [
      'Nike Air Jordan 1 Retro', 'Adidas Yeezy Boost 350', 'Nike Air Force 1 Low', 'Gucci Ace Sneakers', 'Louis Vuitton Trainer', 'Balenciaga Triple S', 'Converse Chuck Taylor 70', 'Vans Old Skool Classic', 'Dr. Martens 1460 Boots', 'Timberland 6-Inch Premium', 'Christian Louboutin Pigalle', 'Hermes Oran Sandals', 'New Balance 990v5', 'Puma Suede Classic', 'Reebok Club C 85', 'Alexander McQueen Oversized', 'Off-White Out Of Office', 'Prada Cloudbust Thunder', 'Common Projects Achilles', 'Birkenstock Arizona SFB'
    ]
  },
  {
    id: 'accessories',
    name: 'Accessories',
    section: 'clothing',
    items: [
      'Rolex Submariner Date', 'Apple Watch Ultra 2', 'Louis Vuitton Neverfull', 'Gucci Marmont Shoulder Bag', 'Ray-Ban Aviator Classic', 'Prada Saffiano Wallet', 'Hermes Birkin 30', 'Cartier Love Bracelet', 'Tiffany & Co. Necklace', 'Montblanc Meisterstuck Pen', 'Bose QuietComfort Ultra', 'Sony WH-1000XM5', 'Rimowa Original Suitcase'
    ]
  }
];
