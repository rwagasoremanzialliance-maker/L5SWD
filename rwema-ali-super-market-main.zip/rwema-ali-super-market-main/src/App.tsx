/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef } from 'react';
import { 
  ShoppingBasket, 
  Shirt, 
  Search, 
  ShoppingCart, 
  ChevronRight, 
  ChevronLeft, 
  Menu, 
  X, 
  Facebook, 
  Instagram, 
  Twitter,
  MapPin,
  Phone,
  Mail,
  ArrowRight,
  Plus,
  Minus,
  Trash2,
  ShieldCheck,
  Leaf,
  CreditCard,
  Headphones
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SUPERMARKET_CATEGORIES, CLOTHING_CATEGORIES, Category } from './data';

type Section = 'home' | 'supermarket' | 'clothing' | 'cart';

interface CartItem {
  name: string;
  price: number;
  quantity: number;
  section: 'supermarket' | 'clothing';
}

export default function App() {
  const [activeSection, setActiveSection] = useState<Section>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [currentHeroImage, setCurrentHeroImage] = useState(0);
  const newArrivalsRef = useRef<HTMLDivElement>(null);

  const scrollNewArrivals = (direction: 'left' | 'right') => {
    if (newArrivalsRef.current) {
      const scrollAmount = 300;
      newArrivalsRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const heroImages = [
    "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1534723452862-4c874018d66d?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1604719312563-8912e9223c6a?auto=format&fit=crop&q=80&w=1920",
    "https://images.pexels.com/photos/264636/pexels-photo-264636.jpeg?auto=compress&cs=tinysrgb&w=1920",
    "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1583258292688-d0213dc5a3a8?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1516594798947-e65505dbb29d?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1520006403909-838d6b92c22e?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1550928431-ee0ec6db30d3?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1513584684374-8bdb74838a0f?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1512436991641-6745cdb1723f?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1516762689617-e1cffcef479d?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1526170315870-ef682c473392?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1491553895911-0055eca6402d?auto=format&fit=crop&q=80&w=1920",
    "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=1920"
  ];

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentHeroImage((prev) => (prev + 1) % heroImages.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const addToCart = (name: string, section: 'supermarket' | 'clothing') => {
    setCart(prev => {
      const existing = prev.find(item => item.name === name);
      if (existing) {
        return prev.map(item => item.name === name ? { ...item, quantity: item.quantity + 1 } : item);
      }
      // Mock price for demo
      const price = section === 'supermarket' ? Math.floor(Math.random() * 20) + 5 : Math.floor(Math.random() * 100) + 20;
      return [...prev, { name, price, quantity: 1, section }];
    });
  };

  const removeFromCart = (name: string) => {
    setCart(prev => prev.filter(item => item.name !== name));
  };

  const updateQuantity = (name: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.name === name) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const cartTotal = useMemo(() => cart.reduce((sum, item) => sum + (item.price * item.quantity), 0), [cart]);

  const filteredSupermarket = useMemo(() => {
    if (!searchQuery) return SUPERMARKET_CATEGORIES;
    return SUPERMARKET_CATEGORIES.map(cat => ({
      ...cat,
      items: cat.items.filter(item => item.toLowerCase().includes(searchQuery.toLowerCase()))
    })).filter(cat => cat.items.length > 0);
  }, [searchQuery]);

  const filteredClothing = useMemo(() => {
    if (!searchQuery) return CLOTHING_CATEGORIES;
    return CLOTHING_CATEGORIES.map(cat => ({
      ...cat,
      items: cat.items.filter(item => item.toLowerCase().includes(searchQuery.toLowerCase()))
    })).filter(cat => cat.items.length > 0);
  }, [searchQuery]);

  const getImageKeywords = useMemo(() => (item: string, categoryName: string) => {
    const cleanItem = item.toLowerCase().replace(/['’]/g, '').split(' ').slice(-1)[0];
    if (categoryName.toLowerCase().includes('shoe')) return `${cleanItem},sneakers,shoes,luxury,product`;
    if (categoryName.toLowerCase().includes('clothing')) return `${cleanItem},fashion,style,flatlay,product`;
    if (categoryName.toLowerCase().includes('accessories')) return `${cleanItem},accessory,luxury,product`;
    if (categoryName.toLowerCase().includes('beverage')) return `${cleanItem},beverage,drink,refreshing,product`;
    if (categoryName.toLowerCase().includes('fresh')) return `${cleanItem},fresh,organic,food,stilllife`;
    if (categoryName.toLowerCase().includes('household')) return `${cleanItem},cleaning,home,product`;
    if (categoryName.toLowerCase().includes('personal')) return `${cleanItem},beauty,care,product`;
    return `${cleanItem},grocery,food,stilllife`;
  }, []);

  const marqueeProductsRow1 = [
    'Hugo Boss Suit', 'Nike Air Jordan', 'Gucci Silk Dress', 'Dr. Martens Boots', 'Rolex Submariner', 
    'Louis Vuitton Bag', 'Chanel Perfume', 'Hermes Scarf', 'Organic Avocado', 'Almarai Milk', 
    'Starbucks Coffee', 'Lindt Chocolate', 'Bertolli Olive Oil', 'Twinings Tea', 'Organic Honey',
    'Premium Red Wine', 'Gouda Cheese', 'Fresh Baguette', 'Free-Range Eggs', 'Barilla Pasta',
    'Heinz Ketchup', 'McCormick Spices', 'Tilda Basmati', 'Organic Quinoa', 'Premium Almonds',
    'Walnuts', 'Dried Apricots', 'Kellogg\'s Cereal', 'Tropicana Juice', 'Perrier Water'
  ];

  const marqueeProductsRow2 = [
    'Scented Candle', 'Luxury Throw', 'Designer Vase', 'Modern Wall Art', 'Glass Table',
    'Lounge Chair', 'Silk Pillow', 'Bath Robe', 'Skincare Set', 'Nivea Cream',
    'Dove Lotion', 'Hair Serum', 'Makeup Kit', 'Dior Lipstick', 'Eye Shadow',
    'Apple Watch', 'Sony Earbuds', 'Bose Speaker', 'iPhone Case', 'Laptop Sleeve',
    'Prada Wallet', 'Rimowa Suitcase', 'Ray-Ban Aviator', 'Gucci Belt', 'Fashion Hat',
    'Yoga Mat', 'Water Bottle', 'Gym Bag', 'Adidas Sneakers', 'Nike Socks'
  ];

  const getMarqueeImage = (item: string, baseKeywords: string) => {
    const cleanItem = item.toLowerCase().replace(/['’]/g, '').split(' ').slice(-1)[0];
    return `https://loremflickr.com/600/800/${cleanItem},${baseKeywords},product,stilllife/all`;
  };

  const NavLink = ({ section, label, icon: Icon }: { section: Section, label: string, icon?: any }) => (
    <button
      onClick={() => { setActiveSection(section); setIsMenuOpen(false); }}
      className={`flex items-center gap-2 px-4 py-2 rounded-full transition-all ${
        activeSection === section 
          ? 'bg-emerald-600 text-white shadow-md' 
          : 'text-zinc-600 hover:bg-zinc-100'
      }`}
    >
      {Icon && <Icon size={18} />}
      <span className="font-medium font-serif italic">{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans selection:bg-emerald-100 selection:text-emerald-900 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-zinc-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setActiveSection('home')}>
              <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white shadow-lg">
                <ShoppingBasket size={24} />
              </div>
              <span className="text-xl font-bold tracking-tight hidden sm:block font-serif italic">RWEMA Ali</span>
            </div>

            <div className="hidden md:flex items-center gap-2">
              <NavLink section="home" label="Home" />
              <NavLink section="supermarket" label="Supermarket" icon={ShoppingBasket} />
              <NavLink section="clothing" label="Clothing" icon={Shirt} />
            </div>

            <div className="flex items-center gap-4">
              <div className="relative hidden sm:block">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-zinc-100 border-none rounded-full focus:ring-2 focus:ring-emerald-500 w-48 lg:w-64 transition-all"
                />
              </div>
              <button 
                onClick={() => setActiveSection('cart')}
                className="relative p-2 text-zinc-600 hover:bg-zinc-100 rounded-full transition-colors"
              >
                <ShoppingCart size={24} />
                {cart.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white">
                    {cart.reduce((s, i) => s + i.quantity, 0)}
                  </span>
                )}
              </button>
              <button 
                className="md:hidden p-2 text-zinc-600 hover:bg-zinc-100 rounded-full"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden fixed inset-0 z-40 bg-white pt-20 px-4"
          >
            <div className="flex flex-col gap-4">
              <NavLink section="home" label="Home" />
              <NavLink section="supermarket" label="Supermarket" icon={ShoppingBasket} />
              <NavLink section="clothing" label="Clothing" icon={Shirt} />
              <div className="relative mt-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                <input
                  type="text"
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-3 bg-zinc-100 border-none rounded-2xl focus:ring-2 focus:ring-emerald-500 w-full"
                />
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          {activeSection === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              {/* Hero Section */}
              <div className="relative rounded-[4rem] overflow-hidden bg-zinc-900 min-h-[900px] flex items-center shadow-2xl shadow-emerald-900/70 border border-white/10">
                <AnimatePresence>
                  <motion.img 
                    key={currentHeroImage}
                    src={heroImages[currentHeroImage]} 
                    initial={{ opacity: 0, scale: 1.1 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 1.5, ease: "easeInOut" }}
                    className="absolute inset-0 w-full h-full object-cover"
                    alt="Ali Market"
                    referrerPolicy="no-referrer"
                  />
                </AnimatePresence>
                <div className="absolute inset-0 bg-black/40" />
                
                <div className="relative z-10 px-8 md:px-32 w-full">
                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 1 }}
                    className="max-w-6xl"
                  >
                    <div className="inline-flex items-center gap-4 px-8 py-3 bg-emerald-500 text-white rounded-full mb-12 shadow-2xl shadow-emerald-500/50">
                      <span className="text-sm font-black tracking-[0.4em] uppercase font-serif italic">
                        Premium Quality Retail
                      </span>
                    </div>
                    <h1 className="text-9xl md:text-[14rem] font-bold text-white mb-12 leading-[0.7] tracking-tighter">
                      <span className="text-emerald-400 font-serif italic">Ali Market</span>
                    </h1>
                    <p className="text-white text-4xl md:text-6xl mb-20 leading-tight max-w-4xl font-serif italic font-bold opacity-90">
                      Fresh Groceries & <br />
                      <span className="text-emerald-300 italic">Designer Fashion.</span>
                    </p>
                    <div className="flex flex-wrap gap-12">
                      <button 
                        onClick={() => setActiveSection('supermarket')}
                        className="bg-emerald-500 hover:bg-emerald-400 text-white px-24 py-10 rounded-[3rem] font-black text-4xl flex items-center gap-8 transition-all transform hover:scale-105 shadow-2xl shadow-emerald-500/60 font-serif italic"
                      >
                        Shop Now <ArrowRight size={48} />
                      </button>
                      <button 
                        onClick={() => setActiveSection('clothing')}
                        className="bg-white/10 hover:bg-white/20 backdrop-blur-xl text-white border-4 border-white/40 px-24 py-10 rounded-[3rem] font-black text-4xl transition-all transform hover:scale-105 font-serif italic"
                      >
                        Fashion
                      </button>
                    </div>
                  </motion.div>
                </div>
              </div>

              {/* Featured Products Section */}
              <div className="space-y-12">
                <div className="flex justify-between items-end">
                  <div>
                    <h2 className="text-5xl font-bold font-serif italic">Featured Products</h2>
                    <p className="text-zinc-500 font-serif italic text-xl mt-2">Hand-picked items for your daily lifestyle.</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {[
                    { name: 'Organic Hass Avocado', price: 4.50, img: 'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&q=80&w=600' },
                    { name: 'Gucci Silk Shirt', price: 890.00, img: 'https://images.unsplash.com/photo-1620012253295-c15cc3e65df4?auto=format&fit=crop&q=80&w=600' },
                    { name: 'Dior Essence Lotion', price: 124.99, img: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&q=80&w=600' },
                  ].map((p, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ y: -10 }}
                      className="bg-white p-8 rounded-[3rem] border border-zinc-100 shadow-xl group"
                    >
                      <div className="aspect-square rounded-[2.5rem] overflow-hidden mb-8">
                        <img src={p.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={p.name} referrerPolicy="no-referrer" />
                      </div>
                      <h3 className="text-3xl font-bold font-serif italic mb-2">{p.name}</h3>
                      <div className="flex justify-between items-center">
                        <span className="text-emerald-600 font-black text-3xl">${p.price.toFixed(2)}</span>
                        <button className="w-16 h-16 bg-zinc-900 text-white rounded-3xl flex items-center justify-center hover:bg-emerald-600 transition-all shadow-xl">
                          <Plus size={32} />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Brand Values Section */}
              <div className="bg-zinc-900 rounded-[4rem] p-16 md:p-24 text-white">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-12 text-center">
                  {[
                    { title: 'Quality First', icon: ShieldCheck, desc: 'We only source the finest products.' },
                    { title: 'Eco Friendly', icon: Leaf, desc: 'Sustainable packaging and practices.' },
                    { title: 'Secure Pay', icon: CreditCard, desc: '100% safe and encrypted payments.' },
                    { title: '24/7 Support', icon: Headphones, desc: 'We are here for you anytime.' },
                  ].map((v, i) => (
                    <motion.div key={i} whileHover={{ scale: 1.05 }}>
                      <div className="w-20 h-20 bg-emerald-500/20 rounded-3xl flex items-center justify-center text-emerald-400 mx-auto mb-8">
                        <v.icon size={40} />
                      </div>
                      <h3 className="text-2xl font-bold mb-4 font-serif italic">{v.title}</h3>
                      <p className="text-zinc-400 font-serif italic">{v.desc}</p>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Featured Categories Grid */}
              <div className="space-y-12">
                <div className="flex justify-between items-end">
                  <div>
                    <h2 className="text-5xl font-bold font-serif italic">Shop by Category</h2>
                    <p className="text-zinc-500 font-serif italic text-xl mt-2">Find exactly what you need in our curated collections.</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                  {[
                    { name: 'Fresh Fruits', img: 'https://images.unsplash.com/photo-1519996529931-28324d5a630e?auto=format&fit=crop&q=80&w=400', count: '120+ Items' },
                    { name: 'Men\'s Fashion', img: 'https://images.unsplash.com/photo-1593030761757-71fae45fa0e7?auto=format&fit=crop&q=80&w=400', count: '85+ Items' },
                    { name: 'Organic Veggies', img: 'https://images.unsplash.com/photo-1597362868479-35442175a6d7?auto=format&fit=crop&q=80&w=400', count: '150+ Items' },
                    { name: 'Luxury Shoes', img: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&q=80&w=400', count: '60+ Items' },
                  ].map((cat, i) => (
                    <motion.div
                      key={i}
                      whileHover={{ y: -10 }}
                      className="group cursor-pointer"
                    >
                      <div className="aspect-square rounded-[3rem] overflow-hidden mb-6 shadow-xl border border-zinc-100">
                        <img src={cat.img} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={cat.name} referrerPolicy="no-referrer" />
                      </div>
                      <h3 className="text-2xl font-bold font-serif italic mb-1">{cat.name}</h3>
                      <p className="text-emerald-600 font-serif italic">{cat.count}</p>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Collection Showcase Marquee */}
              <div className="space-y-8 overflow-hidden py-12">
                <div className="px-8 md:px-32">
                  <h2 className="text-5xl font-bold font-serif italic">Our Global Collection</h2>
                  <p className="text-zinc-500 font-serif italic text-xl mt-2">A glimpse into the thousands of premium products we offer.</p>
                </div>
                
                <div className="relative flex overflow-x-hidden">
                  <motion.div 
                    animate={{ x: ["0%", "-50%"] }}
                    transition={{ duration: 360, repeat: Infinity, ease: "linear" }}
                    className="flex whitespace-nowrap"
                  >
                    {marqueeProductsRow1.map((item, i) => (
                      <div key={i} className="w-[300px] h-[400px] flex-shrink-0 px-2 will-change-transform">
                        <div className="w-full h-full rounded-[2rem] overflow-hidden shadow-lg border border-zinc-100 relative group">
                          <img 
                            src={getMarqueeImage(item, 'fashion,grocery,luxury')} 
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                            alt={item}
                            loading="lazy"
                            decoding="async"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                            <span className="text-white font-bold font-serif italic text-xl">{item}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                    {/* Duplicate for seamless loop */}
                    {marqueeProductsRow1.map((item, i) => (
                      <div key={`dup-${i}`} className="w-[300px] h-[400px] flex-shrink-0 px-2 will-change-transform">
                        <div className="w-full h-full rounded-[2rem] overflow-hidden shadow-lg border border-zinc-100 relative group">
                          <img 
                            src={getMarqueeImage(item, 'fashion,grocery,luxury')} 
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                            alt={item}
                            loading="lazy"
                            decoding="async"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                            <span className="text-white font-bold font-serif italic text-xl">{item}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </motion.div>
                </div>

                <div className="relative flex overflow-x-hidden">
                  <motion.div 
                    animate={{ x: ["-50%", "0%"] }}
                    transition={{ duration: 400, repeat: Infinity, ease: "linear" }}
                    className="flex whitespace-nowrap"
                  >
                    {marqueeProductsRow2.map((item, i) => (
                      <div key={i} className="w-[300px] h-[400px] flex-shrink-0 px-2 will-change-transform">
                        <div className="w-full h-full rounded-[2rem] overflow-hidden shadow-lg border border-zinc-100 relative group">
                          <img 
                            src={getMarqueeImage(item, 'lifestyle,interior,food')} 
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                            alt={item}
                            loading="lazy"
                            decoding="async"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                            <span className="text-white font-bold font-serif italic text-xl">{item}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                    {/* Duplicate for seamless loop */}
                    {marqueeProductsRow2.map((item, i) => (
                      <div key={`dup-${i}`} className="w-[300px] h-[400px] flex-shrink-0 px-2 will-change-transform">
                        <div className="w-full h-full rounded-[2rem] overflow-hidden shadow-lg border border-zinc-100 relative group">
                          <img 
                            src={getMarqueeImage(item, 'lifestyle,interior,food')} 
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                            alt={item}
                            loading="lazy"
                            decoding="async"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                            <span className="text-white font-bold font-serif italic text-xl">{item}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </motion.div>
                </div>
              </div>

              {/* Newsletter Section */}
              <div className="bg-emerald-50 rounded-[4rem] p-16 md:p-24 flex flex-col md:flex-row items-center justify-between gap-12">
                <div className="max-w-xl">
                  <h2 className="text-5xl font-bold font-serif italic mb-6">Join the RWEMA Ali Family</h2>
                  <p className="text-zinc-600 font-serif italic text-xl">Subscribe to our newsletter and get 10% off your first order plus exclusive weekly deals.</p>
                </div>
                <div className="w-full max-w-md flex gap-4">
                  <input 
                    type="email" 
                    placeholder="Enter your email" 
                    className="flex-1 bg-white border border-zinc-200 rounded-3xl px-8 py-6 font-serif italic focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <button className="bg-zinc-900 text-white px-10 py-6 rounded-3xl font-black hover:bg-emerald-600 transition-all font-serif italic">
                    Join
                  </button>
                </div>
              </div>

              {/* Why Choose Us Section */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[
                  { title: 'Fresh Daily', desc: 'Hand-picked fresh produce every single morning.', icon: ShoppingBasket },
                  { title: 'Fast Delivery', desc: 'Home delivery within 60 minutes across Kigali.', icon: MapPin },
                  { title: 'Best Prices', desc: 'Premium quality products at the most competitive prices.', icon: ShoppingCart },
                ].map((feature, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.2 }}
                    className="bg-white p-10 rounded-[2.5rem] border border-zinc-200 shadow-sm hover:shadow-xl transition-all text-center group"
                  >
                    <div className="w-20 h-20 bg-emerald-50 rounded-3xl flex items-center justify-center text-emerald-600 mx-auto mb-6 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-500">
                      <feature.icon size={36} />
                    </div>
                    <h3 className="text-2xl font-bold mb-4 font-serif italic">{feature.title}</h3>
                    <p className="text-zinc-500 font-serif italic text-lg leading-relaxed">{feature.desc}</p>
                  </motion.div>
                ))}
              </div>

              {/* Featured Sections */}
              <div className="grid md:grid-cols-2 gap-10">
                <motion.div 
                  whileHover={{ y: -10 }}
                  onClick={() => setActiveSection('supermarket')}
                  className="group relative h-[450px] rounded-[2.5rem] overflow-hidden cursor-pointer shadow-2xl shadow-emerald-900/10 border border-white/20"
                >
                  <img src="https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&q=80&w=1000" className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" alt="Supermarket" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-900/20 to-transparent flex flex-col justify-end p-10">
                    <span className="text-emerald-400 font-bold text-sm tracking-widest uppercase mb-2">Fresh & Daily</span>
                    <h2 className="text-4xl font-bold text-white mb-3 font-serif italic">Supermarket</h2>
                    <p className="text-zinc-300 font-serif italic text-lg max-w-xs">Premium groceries and household essentials delivered fresh.</p>
                    <div className="mt-6 flex items-center gap-2 text-white font-bold group-hover:gap-4 transition-all">
                      Explore Store <ArrowRight size={20} />
                    </div>
                  </div>
                </motion.div>
                <motion.div 
                  whileHover={{ y: -10 }}
                  onClick={() => setActiveSection('clothing')}
                  className="group relative h-[450px] rounded-[2.5rem] overflow-hidden cursor-pointer shadow-2xl shadow-zinc-900/10 border border-white/20"
                >
                  <img src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?auto=format&fit=crop&q=80&w=1000" className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" alt="Clothing" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-900/20 to-transparent flex flex-col justify-end p-10">
                    <span className="text-emerald-400 font-bold text-sm tracking-widest uppercase mb-2">Trendy & Elegant</span>
                    <h2 className="text-4xl font-bold text-white mb-3 font-serif italic">Clothing Store</h2>
                    <p className="text-zinc-300 font-serif italic text-lg max-w-xs">Latest fashion trends for men, women, and children.</p>
                    <div className="mt-6 flex items-center gap-2 text-white font-bold group-hover:gap-4 transition-all">
                      Browse Fashion <ArrowRight size={20} />
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* New Arrivals Section */}
              <div className="space-y-8">
                <div className="flex justify-between items-end">
                  <div>
                    <h2 className="text-3xl font-bold font-serif italic">New Arrivals</h2>
                    <p className="text-zinc-500 font-serif italic">Check out our latest additions this week.</p>
                  </div>
                  <button className="text-emerald-600 font-bold flex items-center gap-2 hover:gap-3 transition-all font-serif italic">
                    View All <ChevronRight size={20} />
                  </button>
                </div>

                <div className="relative group/arrows">
                  {/* Left Arrow */}
                  <button 
                    onClick={() => scrollNewArrivals('left')}
                    className="absolute -left-6 top-1/2 -translate-y-1/2 z-10 w-14 h-14 bg-white rounded-full border border-zinc-200 flex items-center justify-center hover:bg-zinc-900 hover:text-white transition-all shadow-xl opacity-0 group-hover/arrows:opacity-100 hidden md:flex"
                  >
                    <ChevronLeft size={28} />
                  </button>

                  {/* Right Arrow */}
                  <button 
                    onClick={() => scrollNewArrivals('right')}
                    className="absolute -right-6 top-1/2 -translate-y-1/2 z-10 w-14 h-14 bg-white rounded-full border border-zinc-200 flex items-center justify-center hover:bg-zinc-900 hover:text-white transition-all shadow-xl opacity-0 group-hover/arrows:opacity-100 hidden md:flex"
                  >
                    <ChevronRight size={28} />
                  </button>

                  <div 
                    ref={newArrivalsRef}
                    className="flex gap-6 overflow-x-auto pb-8 no-scrollbar scroll-smooth"
                  >
                  {['Hugo Boss Suit', 'Nike Air Jordan', 'Chanel Silk Dress', 'Dr. Martens Boots', 'Rolex Gold Watch', 'Gucci Handbag', 'Dior Perfume', 'Hermes Silk Scarf'].map((item, idx) => (
                    <motion.div 
                      key={item}
                      whileHover={{ y: -5 }}
                      className="min-w-[280px] bg-white rounded-3xl p-5 border border-zinc-200 shadow-sm hover:shadow-xl transition-all group"
                    >
                      <div className="aspect-[4/5] rounded-2xl bg-zinc-100 mb-4 overflow-hidden relative">
                        <img 
                          src={item === 'Nike Air Jordan' 
                            ? "https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&q=80&w=600"
                            : `https://loremflickr.com/400/500/${encodeURIComponent(item.toLowerCase().split(' ').slice(-1)[0])},fashion,luxury,product,stilllife/all`
                          } 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                          alt={item}
                          loading="lazy"
                          decoding="async"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider text-emerald-600">
                          Trending
                        </div>
                      </div>
                      <h3 className="font-bold text-lg font-serif italic mb-1">{item}</h3>
                      <div className="flex justify-between items-center">
                        <span className="text-emerald-600 font-bold text-xl">${(120 + idx * 45).toFixed(2)}</span>
                        <button 
                          onClick={() => addToCart(item, 'clothing')}
                          className="w-10 h-10 bg-zinc-900 text-white rounded-full flex items-center justify-center hover:bg-emerald-600 transition-colors"
                        >
                          <Plus size={20} />
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>

              {/* Vision & Mission */}
              <div className="bg-white rounded-3xl p-8 md:p-12 border border-zinc-200 shadow-sm">
                <div className="grid md:grid-cols-2 gap-12">
                  <div>
                    <h3 className="text-2xl font-bold mb-4 flex items-center gap-2 font-serif italic">
                      <div className="w-2 h-8 bg-emerald-600 rounded-full" />
                      Our Vision
                    </h3>
                    <p className="text-zinc-600 text-lg leading-relaxed font-serif italic">
                      To become the leading and most trusted supermarket in the region, known for our commitment to quality and community.
                    </p>
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold mb-4 flex items-center gap-2 font-serif italic">
                      <div className="w-2 h-8 bg-emerald-600 rounded-full" />
                      Our Mission
                    </h3>
                    <p className="text-zinc-600 text-lg leading-relaxed font-serif italic">
                      To provide affordable, quality products with excellent customer service, ensuring every customer leaves with a smile.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {(activeSection === 'supermarket' || activeSection === 'clothing') && (
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-12"
            >
              {/* Section Banner */}
              <div className="relative h-64 rounded-[2.5rem] overflow-hidden shadow-xl">
                <img 
                  src={activeSection === 'supermarket' 
                    ? "https://images.unsplash.com/photo-1543168256-418811576931?auto=format&fit=crop&q=80&w=1200"
                    : "https://images.unsplash.com/photo-1445205170230-053b83016050?auto=format&fit=crop&q=80&w=1200"
                  }
                  className="absolute inset-0 w-full h-full object-cover"
                  alt="Banner"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] flex items-center px-12">
                  <div className="max-w-xl">
                    <h1 className="text-5xl font-bold text-white capitalize font-serif italic mb-2">{activeSection}</h1>
                    <p className="text-zinc-200 font-serif italic text-lg">
                      {activeSection === 'supermarket' 
                        ? 'Premium quality groceries and fresh daily essentials.' 
                        : 'Discover the latest trends in global fashion and accessories.'}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex gap-3 overflow-x-auto pb-4 no-scrollbar">
                  {(activeSection === 'supermarket' ? SUPERMARKET_CATEGORIES : CLOTHING_CATEGORIES).map(cat => (
                    <a 
                      key={cat.id} 
                      href={`#${cat.id}`}
                      className="flex items-center gap-2 whitespace-nowrap px-4 py-2 bg-white border border-zinc-200 rounded-full text-sm font-medium hover:border-emerald-500 hover:text-emerald-600 transition-all hover:shadow-md group"
                    >
                      <div className="w-8 h-8 rounded-full overflow-hidden bg-zinc-100 border border-zinc-100">
                        <img 
                          src={`https://loremflickr.com/80/80/${encodeURIComponent(cat.name.toLowerCase().split(' ')[0])},${activeSection === 'supermarket' ? 'grocery' : 'fashion'}`} 
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                          alt=""
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      {cat.name}
                    </a>
                  ))}
                </div>
              </div>

              <div className="space-y-12">
                {(activeSection === 'supermarket' ? filteredSupermarket : filteredClothing).map((category) => (
                  <section key={category.id} id={category.id} className="scroll-mt-24">
                    <h2 className="text-2xl font-bold mb-6 flex items-center gap-3 font-serif italic">
                      <span className="w-1.5 h-6 bg-emerald-600 rounded-full" />
                      {category.name}
                    </h2>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                      {category.items.map((item, idx) => (
                        <motion.div
                          key={item}
                          whileHover={{ y: -8 }}
                          className="bg-white p-5 rounded-[2rem] border border-zinc-200 shadow-sm hover:shadow-2xl transition-all group relative overflow-hidden"
                        >
                          <div className="aspect-square rounded-2xl bg-zinc-100 mb-5 overflow-hidden relative">
                            <img 
                              src={`https://loremflickr.com/500/500/${getImageKeywords(item, category.name)}/all`} 
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out" 
                              alt={item}
                              loading="lazy"
                              decoding="async"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors" />
                            <button className="absolute top-3 right-3 w-10 h-10 bg-white/90 backdrop-blur-md rounded-full flex items-center justify-center text-zinc-400 hover:text-emerald-600 opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0">
                              <Search size={18} />
                            </button>
                          </div>
                          <h3 className="font-bold text-zinc-900 line-clamp-1 font-serif italic text-lg mb-1">{item}</h3>
                          <p className="text-sm text-zinc-500 mb-4 font-serif italic">{category.name}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex flex-col">
                              <span className="text-xs text-zinc-400 line-through font-serif italic">
                                ${(activeSection === 'supermarket' ? (15 + idx % 5) : (65 + idx % 20)).toFixed(2)}
                              </span>
                              <span className="font-bold text-emerald-600 text-xl">
                                ${activeSection === 'supermarket' ? (10 + idx % 5).toFixed(2) : (45 + idx % 20).toFixed(2)}
                              </span>
                            </div>
                            <button 
                              onClick={() => addToCart(item, activeSection as any)}
                              className="w-12 h-12 bg-zinc-900 hover:bg-emerald-600 text-white rounded-2xl flex items-center justify-center transition-all shadow-lg shadow-zinc-900/10"
                            >
                              <Plus size={24} />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </section>
                ))}
              </div>
            </motion.div>
          )}

          {activeSection === 'cart' && (
            <motion.div
              key="cart"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="max-w-3xl mx-auto"
            >
              <h1 className="text-3xl font-bold mb-8">Your Shopping Cart</h1>
              
              {cart.length === 0 ? (
                <div className="text-center py-20 bg-white rounded-3xl border border-zinc-200">
                  <div className="w-20 h-20 bg-zinc-100 rounded-full flex items-center justify-center mx-auto mb-6 text-zinc-400">
                    <ShoppingCart size={40} />
                  </div>
                  <h2 className="text-xl font-semibold mb-2 font-serif italic">Your cart is empty</h2>
                  <p className="text-zinc-500 mb-8 font-serif italic">Looks like you haven't added anything yet.</p>
                  <button 
                    onClick={() => setActiveSection('home')}
                    className="bg-emerald-600 text-white px-8 py-3 rounded-full font-semibold font-serif italic"
                  >
                    Start Shopping
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="bg-white rounded-3xl border border-zinc-200 overflow-hidden">
                    {cart.map((item) => (
                      <div key={item.name} className="flex items-center gap-4 p-6 border-b border-zinc-100 last:border-0">
                        <div className="w-20 h-20 rounded-xl bg-zinc-100 overflow-hidden flex-shrink-0">
                          <img src={`https://picsum.photos/seed/${item.name}/200/200`} className="w-full h-full object-cover" alt={item.name} referrerPolicy="no-referrer" />
                        </div>
                        <div className="flex-grow">
                          <h3 className="font-bold font-serif italic">{item.name}</h3>
                          <p className="text-sm text-zinc-500 capitalize font-serif italic">{item.section}</p>
                          <p className="text-emerald-600 font-bold mt-1 font-serif italic">${item.price.toFixed(2)}</p>
                        </div>
                        <div className="flex items-center gap-3 bg-zinc-100 rounded-full px-3 py-1">
                          <button onClick={() => updateQuantity(item.name, -1)} className="p-1 hover:text-emerald-600"><Minus size={16} /></button>
                          <span className="font-bold w-6 text-center">{item.quantity}</span>
                          <button onClick={() => updateQuantity(item.name, 1)} className="p-1 hover:text-emerald-600"><Plus size={16} /></button>
                        </div>
                        <button 
                          onClick={() => removeFromCart(item.name)}
                          className="p-2 text-zinc-400 hover:text-red-500 transition-colors"
                        >
                          <Trash2 size={20} />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="bg-white rounded-3xl border border-zinc-200 p-8">
                    <div className="flex justify-between items-center mb-6 text-lg">
                      <span className="text-zinc-500">Subtotal</span>
                      <span className="font-bold">${cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center mb-8 text-lg">
                      <span className="text-zinc-500">Delivery Fee</span>
                      <span className="font-bold text-emerald-600">FREE</span>
                    </div>
                    <div className="border-t border-zinc-100 pt-6 flex justify-between items-center mb-8">
                      <span className="text-2xl font-bold">Total</span>
                      <span className="text-2xl font-bold text-emerald-600">${cartTotal.toFixed(2)}</span>
                    </div>
                    <button className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-4 rounded-2xl font-bold text-lg shadow-lg shadow-emerald-900/20 transition-all">
                      Proceed to Checkout
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-zinc-900 text-white pt-20 pb-10 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="space-y-6">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center text-white">
                  <ShoppingBasket size={24} />
                </div>
                <span className="text-2xl font-bold tracking-tight font-serif italic">RWEMA Ali</span>
              </div>
              <p className="text-zinc-400 leading-relaxed font-serif italic">
                Your trusted partner for quality groceries and fashion. Providing excellence in retail since 2024.
              </p>
              <div className="flex gap-4">
                <a href="#" className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center hover:bg-emerald-600 transition-colors"><Facebook size={20} /></a>
                <a href="#" className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center hover:bg-emerald-600 transition-colors"><Twitter size={20} /></a>
                <a href="#" className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center hover:bg-emerald-600 transition-colors"><Instagram size={20} /></a>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-6 font-serif italic">Quick Links</h4>
              <ul className="space-y-4 text-zinc-400 font-serif italic">
                <li><button onClick={() => setActiveSection('home')} className="hover:text-emerald-400 transition-colors">Home</button></li>
                <li><button onClick={() => setActiveSection('supermarket')} className="hover:text-emerald-400 transition-colors">Supermarket</button></li>
                <li><button onClick={() => setActiveSection('clothing')} className="hover:text-emerald-400 transition-colors">Clothing Store</button></li>
                <li><button onClick={() => setActiveSection('cart')} className="hover:text-emerald-400 transition-colors">Shopping Cart</button></li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-6 font-serif italic">Contact Us</h4>
              <ul className="space-y-4 text-zinc-400 font-serif italic">
                <li className="flex items-center gap-3"><MapPin size={18} className="text-emerald-500" /> Kigali, Rwanda</li>
                <li className="flex items-center gap-3"><Phone size={18} className="text-emerald-500" /> +250 788 000 000</li>
                <li className="flex items-center gap-3"><Mail size={18} className="text-emerald-500" /> info@rwemaali.com</li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-bold mb-6 font-serif italic">Newsletter</h4>
              <p className="text-zinc-400 mb-4 font-serif italic">Subscribe to get special offers and updates.</p>
              <div className="flex gap-2">
                <input 
                  type="email" 
                  placeholder="Your email" 
                  className="bg-zinc-800 border-none rounded-xl px-4 py-2 flex-grow focus:ring-2 focus:ring-emerald-500"
                />
                <button className="bg-emerald-600 p-2 rounded-xl hover:bg-emerald-700 transition-colors">
                  <ArrowRight size={20} />
                </button>
              </div>
            </div>
          </div>
          <div className="border-t border-zinc-800 pt-8 text-center text-zinc-500 text-sm">
            <p>&copy; 2024 RWEMA Ali SUPER MARKET. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
